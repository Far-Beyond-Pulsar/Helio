from pathlib import Path
import csv
import hashlib
import json
import re
import statistics

root = Path(__file__).parent
report = {"selection": {}, "flights": {}, "binaries": {}}
for kind in ["baseline", "candidate"]:
    runs = []
    for repeat in range(3):
        rows = []
        for line in (root / f"bounds-{kind}-selection-{repeat}.log").read_text().splitlines():
            if "SELECTION_FLIGHT" in line:
                rows.append({
                    k: float(v) if "." in v else int(v)
                    for k, v in re.findall(r"(\w+)=([\d.]+)", line)
                })
        assert len(rows) == 7
        runs.append(rows)
    report["selection"][kind] = [{
        k: statistics.median(run[step][k] for run in runs)
        for k in runs[0][step]
    } for step in range(7)]

for name in ["canonical-fixed-sun-quality", "bounds-corner-quality", "bounds-corner-native"]:
    path = root / name
    if not path.exists():
        continue
    captures = {}
    for f in path.glob("*.canonical.csv"):
        rays = list(csv.DictReader(f.open()))
        hits = [r for r in rays if r["cpu_hit"] == r["gpu_status"] == "1"]
        same = [r for r in hits if all(r["gpu_" + a] == r["cpu_" + a] for a in "xyz")]
        errors = sorted(float(r["depth_error_m"]) for r in hits)
        captures[f.stem] = {
            "rays": len(rays), "hits": len(hits), "same_cell": len(same),
            "gpu_in_air": sum(r["canonical_at_gpu"] == "0" for r in hits),
            "coverage_mismatches": sum(r["cpu_hit"] != r["gpu_status"] for r in rays),
            "depth_p95_m": errors[int((len(errors) - 1) * .95)],
            "same_cell_over_1mm": sum(float(r["depth_error_m"]) > .001 for r in same),
        }
        if name != "canonical-fixed-sun-quality":
            baseline = root / "canonical-fixed-sun-quality" / f.name
            if baseline.exists():
                original = list(csv.DictReader(baseline.open()))
                keys = ["x", "y", "width", "height"] + [kind + "_" + a for kind in ["origin", "ray"] for a in "xyz"]
                captures[f.stem]["rays_matching_prior_quality"] = sum(
                    all(a[k] == b[k] for k in keys) for a, b in zip(original, rays)
                )
    audits = {}
    for suffix in ["hits", "sun"]:
        records = [next(csv.DictReader(f.open())) for f in path.glob(f"*.{suffix}.csv")]
        audits[suffix] = {
            "captures": len(records),
            "exhausted": sum(int(r["exhausted"]) for r in records),
            "invalid": sum(int(r.get("invalid", 0)) for r in records),
        }
    report["flights"][name] = {"canonical": captures, "audits": audits}

for name in ["bounds-baseline-tests.exe", "bounds-candidate-tests.exe",
             "bounds-candidate-flight.exe", "corner-baseline-flight.exe",
             "bounds-corner-fixed-flight.exe"]:
    path = root / name
    if path.exists():
        report["binaries"][name] = hashlib.sha256(path.read_bytes()).hexdigest()
(root / "bounds-analysis.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report["flights"], indent=2))
