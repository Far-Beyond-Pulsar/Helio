from pathlib import Path
import hashlib, json, subprocess, zipfile

ROOT = Path(__file__).parent
REPO = ROOT.parent.parent
DEST = REPO/'crates/passes/3d/helio-pass-tiny-voxel/validation/2026-09-26-regional'
DEST.mkdir(parents=True, exist_ok=True)
names = ['regional-first','regional-control','regional-720','regional-specialized-720','regional-control-720','regional-canonical']
entries = {}
movement = {}
for name in names:
    run = ROOT/name
    log = ROOT/(name+'.log')
    assert log.exists() and 'VOXEL_FLIGHT_COMPLETE' in log.read_text(), name
    entries[name+'.log'] = log.read_bytes().replace(b'\r\n',b'\n')
    for f in sorted(run.glob('*.csv')):
        entries[name+'/'+f.name] = f.read_bytes().replace(b'\r\n',b'\n')
    for f in sorted(run.glob('*.png')):
        data = f.read_bytes()
        movement[name+'/'+f.name] = {'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
for f in ['200m.png','orbit.png','returned-ground.png','descent-180.png']:
    entries['screens/'+f] = (ROOT/'regional-specialized-720'/f).read_bytes()
for f in ['regional-analysis.json','analyze-regional.py','archive-regional.py',
          'regional-tests.log','regional-gpu-tests.log','regional-combined-tests.log',
          'regional-specialized-tests.log','regional-default-tests.log']:
    entries[f] = (ROOT/f).read_bytes().replace(b'\r\n',b'\n')
sources = ['Cargo.toml','src/engine/residency.rs','src/engine/residency/tests.rs',
           'src/engine/residency/regional.rs','src/engine/residency/regional/tests.rs',
           'src/engine/stored.wgsl','src/engine/terrain.rs','src/engine/regional_gpu_tests.rs']
sources = ['crates/passes/3d/helio-pass-tiny-voxel/'+f for f in sources]
sources += ['crates/helio-default-graphs/examples/voxel_flight.rs']
for f in sources:
    entries['retained-source/'+f] = (REPO/f).read_bytes().replace(b'\r\n',b'\n')
binaries = {}
for name in ['regional-first','regional-control','regional-specialized','regional-canonical']:
    data = (ROOT/(name+'.exe')).read_bytes()
    binaries[name+'.exe'] = {'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
metadata = {
    'source_base':'66100ff8990c94ab5374e857355fe2b7d047b774',
    'retained_source_applies_to':['regional-specialized-720','regional-canonical'],
    'historical_variants':{'regional-first':'always decode shader; 320p', 'regional-720':'same binary as regional-first; 720p',
                           'regional-control':'feature disabled; 320p','regional-control-720':'same control binary; 720p'},
    'timing_scope':'Recorded/instrumented offscreen diagnostics. Contention not excluded; no acceptance timing claim.',
    'rustc':subprocess.check_output(['rustc','+1.98','-Vv'],text=True).strip(),
}
entries['provenance.json'] = (json.dumps(metadata,indent=2)+'\n').encode()
manifest = {}
with zipfile.ZipFile(DEST/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(entries.items()):
        z.writestr(name,data)
        manifest[name] = {'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
for file,data in [('manifest.json',manifest),('binary-hashes.json',binaries),('movement-frame-hashes.json',movement)]:
    (DEST/file).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
(DEST/'.gitattributes').write_text('* text=auto eol=lf\n*.zip binary\n',encoding='utf-8',newline='\n')
with zipfile.ZipFile(DEST/'evidence.zip') as z:
    for name,info in manifest.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == info['sha256']
print('VERIFIED',len(manifest),'entries;',len(movement),'images hashed;', (DEST/'evidence.zip').stat().st_size,'archive bytes')
