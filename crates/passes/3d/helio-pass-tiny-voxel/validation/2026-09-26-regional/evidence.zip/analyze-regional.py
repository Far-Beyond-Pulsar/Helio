from pathlib import Path
import csv, hashlib, json, math, re

ROOT = Path(__file__).parent
NAMES = ['regional-first', 'regional-control', 'regional-720',
         'regional-specialized-720', 'regional-control-720', 'regional-canonical']

def rows(path):
    return list(csv.DictReader(path.open(encoding='utf-8-sig')))

def stats(values):
    values = sorted(values)
    return {key: values[math.ceil(len(values)*q)-1] for key,q in [('p50',.5),('p95',.95),('p99',.99),('max',1)]} if values else {}

report = {}
for name in NAMES:
    path = ROOT/name
    log = ROOT/(name+'.log')
    if not log.exists() or 'VOXEL_FLIGHT_COMPLETE' not in log.read_text():
        continue
    frames = rows(path/'frames.csv')
    gpu = rows(path/'gpu.csv')
    publications = [r for i,r in enumerate(frames) if int(r['regional_publications']) > (int(frames[i-1]['regional_publications']) if i else 0)]
    stages = {}
    for stage in dict.fromkeys(r['stage'] for r in frames):
        rs = [r for r in frames if r['stage']==stage]
        partials = [r for r in publications if r['stage']==stage]
        settled = [r for r in rs if r['ready']=='true' and r['refining']==r['planning']=='false' and int(r['pending'])==0]
        selected = settled[-60:] if stage in ['200m','1km','orbit'] else rs
        ids = {r['frame'] for r in selected}
        stages[stage] = {
            'frames':len(rs), 'regional_publications':len(partials),
            'first_partial_observed_ms': (int(partials[0]['start_unix_ns'])-int(rs[0]['start_unix_ns']))/1e6 if partials else None,
            'sync_frame_ms':stats([float(r['sync_frame_ms']) for r in selected]),
            'partial_submit_ms':stats([float(r['cpu_submit_ms']) for r in partials]),
            'gpu_ms':{s:stats([float(r['gpu_ms']) for r in gpu if r['flight_frame'] in ids and r['pass']==s]) for s in ['voxel_generation','voxel_primary','voxel_gbuffer','voxel_sun']},
        }
    audits = {}
    for suffix, columns in [('hits',['loading','exhausted']),('sun',['invalid','exhausted'])]:
        captures = [rows(f)[0] for f in path.glob('*.'+suffix+'.csv') if 'composition-sentinel' not in f.name]
        audits[suffix] = {'captures':len(captures), **{key:sum(int(r[key]) for r in captures) for key in columns}}
    fidelity = {}
    for f in path.glob('*.canonical.csv'):
        rays = rows(f)
        hits = [r for r in rays if r['cpu_hit']==r['gpu_status']=='1']
        fidelity[f.stem] = {
            'rays':len(rays), 'coverage_differences':sum(r['cpu_hit']!=r['gpu_status'] for r in rays),
            'first_cell_differences':sum(any(r['cpu_'+a]!=r['gpu_'+a] for a in 'xyz') for r in hits),
            'air_hits':sum(r['canonical_at_gpu']=='0' for r in hits),
            'depth_error_m':stats([float(r['depth_error_m']) for r in hits]),
        }
    report[name] = {
        'frames':len(frames), 'images':len(list(path.glob('*.png'))),
        'regional_publications':int(frames[-1]['regional_publications']),
        'fallback_frames':sum(int(r.get('fallback_regions','0'))>0 for r in frames) if 'fallback_regions' in frames[0] else None,
        'max_fallback_regions':max(int(r.get('fallback_regions','0')) for r in frames) if 'fallback_regions' in frames[0] else None,
        'max_nodes':max(int(r['nodes']) for r in frames),
        'audits':audits, 'fidelity':fidelity, 'stages':stages,
        'logical_memory':rows(path/'memory.csv'),
        'settle_ms':dict((stage,float(ms)) for stage,ms in re.findall(r'VOXEL_FLIGHT_SETTLED stage=(\S+) load_ms=([\d.]+)',log.read_text())),
    }
(ROOT/'regional-analysis.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
for name,data in report.items():
    print(name, 'frames',data['frames'],'publications',data['regional_publications'],'fallback_frames',data['fallback_frames'],data['audits'])
    print('settle_ms',data['settle_ms'])
    for stage in ['200m','1km','orbit','descent']:
        s=data['stages'][stage]
        print(stage,'first_partial_ms',s['first_partial_observed_ms'],'frame_ms',s['sync_frame_ms'],'primary_ms',s['gpu_ms']['voxel_primary'])
