from pathlib import Path
import csv, hashlib, json, math, statistics

root = Path(__file__).parent
def rows(path):
    return list(csv.DictReader(path.open()))
def quantile(values, q):
    values = sorted(values)
    return values[int((len(values)-1)*q)] if values else None
report = {}
names = ["canonical-far-initial", "canonical-far-compensated", "canonical-far-sun-640", "canonical-far-final", "canonical-far-helper-order", "canonical-retained", "canonical-far-default"]
for name in names:
    path = root / name
    log = root / (name + ".log")
    if not path.exists() or not log.exists() or "VOXEL_FLIGHT_COMPLETE" not in log.read_text():
        continue
    captures = {}
    for f in sorted(path.glob("*.canonical.csv")):
        data = rows(f)
        hits = [r for r in data if r["cpu_hit"] == r["gpu_status"] == "1"]
        same = [r for r in hits if all(r["gpu_"+a] == r["cpu_"+a] for a in "xyz")]
        captures[f.stem] = {
            "rays":len(data), "hits":len(hits), "same_cell":len(same),
            "air_hits":sum(r["canonical_at_gpu"]=="0" for r in hits),
            "coverage_mismatch":sum(r["cpu_hit"]!=r["gpu_status"] for r in data),
            "depth_p95_m":quantile([float(r["depth_error_m"]) for r in hits],.95),
            "depth_max_m":max((float(r["depth_error_m"]) for r in hits), default=None),
        }
        if name == "canonical-far-compensated":
            baseline = rows(root / "canonical-far-initial" / f.name)
            keys = ["x","y","width","height"] + [p+"_"+a for p in ["origin","ray"] for a in "xyz"]
            captures[f.stem]["identical_rays_to_initial"] = sum(all(a[k]==b[k] for k in keys) for a,b in zip(data,baseline))
    frames = rows(path / "frames.csv")
    gpu = rows(path / "gpu.csv")
    stages = {}
    for stage in ["200m", "1km", "orbit"]:
        sampled = [r for r in frames if r["stage"]==stage and r["refining"]=="false"][-60:]
        frame_ids = {r["frame"] for r in sampled}
        stages[stage] = {"n":len(sampled),
            "frame_p50_ms":quantile([float(r["sync_frame_ms"]) for r in sampled],.5),
            "frame_p95_ms":quantile([float(r["sync_frame_ms"]) for r in sampled],.95),
            "gpu":{}}
        for domain, stage_pass in sorted({(r["domain"],r["pass"]) for r in gpu}):
            if "voxel" not in domain.lower() and stage_pass not in ["whole_graph", "LazyEngineVoxel"]:
                continue
            values = [float(r["gpu_ms"]) for r in gpu if r["flight_frame"] in frame_ids and r["pass"]==stage_pass and r["domain"]==domain]
            if values:
                stages[stage]["gpu"][domain+":"+stage_pass] = {"p50":quantile(values,.5),"p95":quantile(values,.95)}
    audits = {}
    for suffix, failures in [("hits",["exhausted","loading"]),("sun",["exhausted","invalid"])]:
        samples = [rows(f)[0] for f in path.glob("*."+suffix+".csv") if f.stem != "composition-sentinel."+suffix]
        audits[suffix] = {"captures":len(samples), **{key:sum(int(r[key]) for r in samples) for key in failures}}
    report[name] = {"frames":len(frames), "images":len(list(path.glob("*.png"))),
        "canonical":captures,"audits":audits,"steady_diagnostic":stages,"logical_memory":rows(path/"memory.csv")}
(root / "canonical-far-analysis.json").write_text(json.dumps(report,indent=2)+"\n")
for name, result in report.items():
    print(name, result["frames"], result["audits"])
    print("canonical",result["canonical"])
    print("steady",result["steady_diagnostic"])
